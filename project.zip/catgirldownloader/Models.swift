// Models.swift
// CatgirlDownloader – macOS (Swift/SwiftUI)

import Foundation

// MARK: - NSFW Filter

enum NSFWOption: String, CaseIterable, Identifiable {
    case blockNSFW    = "Block NSFW"
    case showAll      = "Show everything"
    case onlyNSFW     = "Only NSFW"

    var id: String { rawValue }
    
    var displayName: String { rawValue }
}

// MARK: - Image Source

enum ImageSource: String, CaseIterable, Identifiable {
    case catgirl  = "catgirl"
    case waifu    = "waifu"
    case danbooru = "danbooru"

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .catgirl:  return "🐱 Catgirl"
        case .waifu:    return "✨ Waifu"
        case .danbooru: return "🎨 Danbooru"
        }
    }

    var description: String {
        switch self {
        case .catgirl:  return "nekos.moe"
        case .waifu:    return "waifu.im"
        case .danbooru: return "danbooru.donmai.us"
        }
    }
}

// MARK: - Fetched Image Result

struct FetchedImage {
    let data:      Data
    let extension_: String?   // "jpg", "png", …
    let artist:    String?
    let sourceURL: URL?
    let filename:  String
}
