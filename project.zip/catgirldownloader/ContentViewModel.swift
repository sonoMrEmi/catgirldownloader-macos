// ContentViewModel.swift

import SwiftUI
import Combine
import UniformTypeIdentifiers

@MainActor
final class ContentViewModel: ObservableObject {

    // MARK: - Published state

    @Published var image:        NSImage?     = nil
    @Published var isLoading:    Bool         = false
    @Published var errorMessage: String?      = nil
    @Published var statusText:   String       = "Ready"

    // Current image metadata
    @Published var currentArtist:    String?  = nil
    @Published var currentSourceURL: URL?     = nil
    @Published var currentFilename:  String   = "image"
    @Published var currentImageData: Data?    = nil

    private let prefs = UserPreferences.shared
    private var autoReloadTask: Task<Void, Never>?
    private var cancellables   = Set<AnyCancellable>()

    init() {
        // Re-schedule auto-reload when settings change
        prefs.$autoReloadEnabled
            .combineLatest(prefs.$autoReloadInterval)
            .sink { [weak self] enabled, _ in
                self?.rescheduleAutoReload(enabled: enabled)
            }
            .store(in: &cancellables)
    }

    deinit {
        autoReloadTask?.cancel()
    }

    // MARK: - Fetch

    func reload() {
        guard !isLoading else { return }
        cancelAutoReload()

        Task { await fetch() }
    }

    private func fetch() async {
        isLoading    = true
        errorMessage = nil
        statusText   = "Fetching image…"

        do {
            let api    = makeAPI()
            let result = try await api.fetchImage(nsfw: prefs.nsfwMode)

            if let nsImg = NSImage(data: result.data) {
                image            = nsImg
                currentArtist    = result.artist
                currentSourceURL = result.sourceURL
                currentFilename  = result.filename
                currentImageData = result.data
                errorMessage     = nil
                statusText       = "Image loaded ✓"
            } else {
                throw APIError.parseError
            }

        } catch {
            errorMessage = error.localizedDescription
            statusText   = "Error — try refreshing"
        }

        isLoading = false
        scheduleAutoReloadIfNeeded()
    }

    // MARK: - Auto-reload

    func rescheduleAutoReload(enabled: Bool) {
        cancelAutoReload()
        if enabled && !isLoading { scheduleAutoReloadIfNeeded() }
    }

    private func scheduleAutoReloadIfNeeded() {
        guard prefs.autoReloadEnabled else { return }
        cancelAutoReload()
        let interval = max(1, prefs.autoReloadInterval)
        autoReloadTask = Task {
            try? await Task.sleep(for: .seconds(interval))
            guard !Task.isCancelled else { return }
            await fetch()
        }
    }

    private func cancelAutoReload() {
        autoReloadTask?.cancel()
        autoReloadTask = nil
    }

    // MARK: - Save

    func saveImage() {
        guard let data = currentImageData else { return }
        let panel = NSSavePanel()
        panel.nameFieldStringValue = currentFilename
        panel.canCreateDirectories = true
        if let ext = currentFilename.split(separator: ".").last {
            panel.allowedContentTypes = [.init(filenameExtension: String(ext)) ?? .data]
        }
        panel.begin { response in
            guard response == .OK, let url = panel.url else { return }
            try? data.write(to: url)
        }
    }

    // MARK: - API factory

    private func makeAPI() -> any ImageDownloaderAPI {
        switch prefs.selectedSource {
        case .catgirl:  return CatgirlAPI()
        case .waifu:    return WaifuAPI()
        case .danbooru: return DanbooruAPI(tags: prefs.danbooruTags)
        }
    }
}
