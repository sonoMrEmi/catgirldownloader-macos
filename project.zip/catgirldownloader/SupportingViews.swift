// SupportingViews.swift
// Sheets / dialogs used by ContentView.

import SwiftUI

// MARK: - Colour helpers (re-used from ContentView palette)

private enum P {
    static let bg       = Color(hex: "#1e1e2e")
    static let surface  = Color(hex: "#2a2a3e")
    static let accent   = Color(hex: "#cba6f7")
    static let text     = Color(hex: "#cdd6f4")
    static let textDim  = Color(hex: "#a6adc8")
    static let textMute = Color(hex: "#7f849c")
}

// MARK: - Preferences

struct PreferencesView: View {
    @EnvironmentObject var prefs: UserPreferences
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Title bar
            HStack {
                Text("Preferences")
                    .font(.title2.bold())
                    .foregroundColor(P.text)
                Spacer()
                Button("Done") { dismiss() }
                    .buttonStyle(.borderedProminent)
                    .tint(P.accent)
                    .foregroundColor(.black)
            }
            .padding(20)
            .background(P.surface)

            Divider().background(Color(hex: "#45475a"))

            Form {
                // Content filter
                Section {
                    Picker("Filter", selection: $prefs.nsfwMode) {
                        ForEach(NSFWOption.allCases) { opt in
                            Text(opt.rawValue).tag(opt)
                        }
                    }
                    .pickerStyle(.segmented)
                    .onChange(of: prefs.nsfwMode) { _ in prefs.save() }
                } header: {
                    Label("Content Filter", systemImage: "eye.slash")
                        .foregroundColor(P.textDim)
                }

                // Auto-reload
                Section {
                    HStack {
                        Stepper(
                            value: $prefs.autoReloadInterval,
                            in: 1...3600,
                            step: 1
                        ) {
                            Text("\(prefs.autoReloadInterval) seconds")
                                .foregroundColor(P.text)
                        }
                        .onChange(of: prefs.autoReloadInterval) { _ in prefs.save() }
                    }
                } header: {
                    Label("Auto-Reload Interval", systemImage: "timer")
                        .foregroundColor(P.textDim)
                }
            }
            .formStyle(.grouped)
            .scrollContentBackground(.hidden)
            .background(P.bg)
        }
        .background(P.bg)
        .frame(width: 400, height: 300)
    }
}

// MARK: - Danbooru Tags

struct DanbooruTagsView: View {
    @EnvironmentObject var prefs: UserPreferences
    @Environment(\.dismiss) var dismiss

    @State private var localTags: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("Danbooru Tags")
                    .font(.title2.bold())
                    .foregroundColor(P.text)
                Spacer()
                Button("Save") {
                    let clean = DanbooruAPI.sanitize(tags: localTags)
                    prefs.danbooruTags = clean
                    prefs.save()
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .tint(P.accent)
                .foregroundColor(.black)
            }
            .padding(20)
            .background(P.surface)

            Divider().background(Color(hex: "#45475a"))

            VStack(alignment: .leading, spacing: 8) {
                Label("Search Tags", systemImage: "tag")
                    .font(.headline)
                    .foregroundColor(P.text)

                Text("Space-separated tags — e.g. cat_ears solo 1girl")
                    .font(.caption)
                    .foregroundColor(P.textDim)

                TextField("e.g. cat_ears solo", text: $localTags)
                    .textFieldStyle(.roundedBorder)
                    .font(.body)

                Text("Note: some tags are automatically filtered per Danbooru's content policy.")
                    .font(.caption2)
                    .foregroundColor(P.textMute)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(20)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .background(P.bg)
        }
        .background(P.bg)
        .frame(width: 380, height: 240)
        .onAppear { localTags = prefs.danbooruTags }
    }
}

// MARK: - Art Info

struct ArtInfoView: View {
    let artist:    String?
    let sourceURL: URL?
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(spacing: 16) {
            Text("🎨 Art Info")
                .font(.title2.bold())
                .foregroundColor(P.text)

            Divider().background(Color(hex: "#45475a"))

            if let artist = artist {
                HStack {
                    Image(systemName: "person.fill")
                        .foregroundColor(P.accent)
                    Text("Artist: \(artist)")
                        .foregroundColor(P.text)
                }
            }

            if let url = sourceURL {
                Link(destination: url) {
                    Label("Open source page", systemImage: "arrow.up.right.square")
                        .foregroundColor(P.accent)
                }
            }

            if artist == nil && sourceURL == nil {
                Text("No info available for this image.")
                    .foregroundColor(P.textDim)
            }

            Button("Close") { dismiss() }
                .buttonStyle(.borderedProminent)
                .tint(P.accent)
                .foregroundColor(.black)
        }
        .padding(24)
        .background(P.bg)
        .frame(width: 340, height: 220)
    }
}

// MARK: - About

struct AboutView: View {
    let artist:    String?
    let sourceURL: URL?
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack(spacing: 14) {
            Text("🐱")
                .font(.system(size: 56))

            Text("Catgirl Downloader")
                .font(.title.bold())
                .foregroundColor(P.accent)

            Text("Version 0.5  •  Swift/SwiftUI macOS port")
                .font(.subheadline)
                .foregroundColor(P.textDim)

            Divider().background(Color(hex: "#45475a"))

            Text("© 2026 SilverOS / NyarchLinux developers team")
                .font(.caption)
                .foregroundColor(P.textDim)
            Text("macOS Swift port — ported from GTK4 original")
                .font(.caption2)
                .foregroundColor(P.textMute)

            if artist != nil || sourceURL != nil {
                Divider().background(Color(hex: "#45475a"))
                if let a = artist {
                    Text("Artist: \(a)")
                        .foregroundColor(P.text)
                        .font(.subheadline)
                }
                if let url = sourceURL {
                    Link(destination: url) {
                        Label(url.absoluteString, systemImage: "link")
                            .foregroundColor(P.accent)
                            .font(.caption)
                    }
                }
            }

            Button("Close") { dismiss() }
                .buttonStyle(.borderedProminent)
                .tint(P.accent)
                .foregroundColor(.black)
                .padding(.top, 4)
        }
        .padding(28)
        .background(P.bg)
        .frame(width: 360, height: 340)
    }
}
