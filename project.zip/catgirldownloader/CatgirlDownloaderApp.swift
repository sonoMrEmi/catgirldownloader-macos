// CatgirlDownloaderApp.swift
// Entry point – @main App with native macOS menu bar.

import SwiftUI

@main
struct CatgirlDownloaderApp: App {

    @ObservedObject private var prefs = UserPreferences.shared
    @State private var showPreferences = false
    @State private var showAbout       = false

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
        .windowStyle(.automatic)
        .commands {
            // ── File menu ────────────────────────────────────────────────
            CommandGroup(replacing: .newItem) {
                Button("Refresh Image") {
                    NotificationCenter.default.post(name: .reload, object: nil)
                }
                .keyboardShortcut("r", modifiers: .command)

                Button("Save Image…") {
                    NotificationCenter.default.post(name: .saveImage, object: nil)
                }
                .keyboardShortcut("s", modifiers: .command)
            }

            // ── App menu – Preferences ────────────────────────────────────
            CommandGroup(replacing: .appSettings) {
                Button("Preferences…") {
                    NotificationCenter.default.post(name: .showPreferences, object: nil)
                }
                .keyboardShortcut(",", modifiers: .command)
            }

            // ── Help / About ──────────────────────────────────────────────
            CommandGroup(replacing: .appInfo) {
                Button("About Catgirl Downloader") {
                    NotificationCenter.default.post(name: .showAbout, object: nil)
                }
            }
        }

        // macOS 13+ Settings scene (Preferences window via ⌘,)
        Settings {
            PreferencesView()
                .environmentObject(prefs)
        }
    }
}

// MARK: - Notification names for decoupled menu → view communication

extension Notification.Name {
    static let reload          = Notification.Name("CG.reload")
    static let saveImage       = Notification.Name("CG.saveImage")
    static let showPreferences = Notification.Name("CG.showPreferences")
    static let showAbout       = Notification.Name("CG.showAbout")
}
