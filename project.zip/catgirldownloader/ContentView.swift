// ContentView.swift
// Main window UI – dark Catppuccin-inspired palette, native macOS controls.

import SwiftUI

// MARK: - Palette

private enum C {
    static let bg       = Color(hex: "#1e1e2e")
    static let surface  = Color(hex: "#2a2a3e")
    static let surface2 = Color(hex: "#313145")
    static let accent   = Color(hex: "#cba6f7")
    static let text     = Color(hex: "#cdd6f4")
    static let textDim  = Color(hex: "#a6adc8")
    static let textMute = Color(hex: "#7f849c")
    static let border   = Color(hex: "#45475a")
    static let danger   = Color(hex: "#f38ba8")
}

extension Color {
    init(hex: String) {
        let h   = hex.trimmingCharacters(in: .init(charactersIn: "#"))
        let val = UInt64(h, radix: 16) ?? 0
        let r   = Double((val >> 16) & 0xFF) / 255
        let g   = Double((val >> 8)  & 0xFF) / 255
        let b   = Double(val         & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }
}

// MARK: - ContentView

struct ContentView: View {
    
    @StateObject private var vm   = ContentViewModel()
    @ObservedObject  private var prefs = UserPreferences.shared
    
    @State private var showPreferences   = false
    @State private var showAbout         = false
    @State private var showDanbooruSheet = false
    @State private var showArtInfo       = false
    
    var body: some View {
        VStack(spacing: 0) {
            toolbar
            imageArea
            bottomBar
        }
        .background(C.bg)
        .frame(minWidth: 560, minHeight: 620)
        // Preferences sheet
        .sheet(isPresented: $showPreferences) {
            PreferencesView()
                .environmentObject(prefs)
        }
        // About sheet
        .sheet(isPresented: $showAbout) {
            AboutView(artist: vm.currentArtist, sourceURL: vm.currentSourceURL)
        }
        // Danbooru tags sheet
        .sheet(isPresented: $showDanbooruSheet) {
            DanbooruTagsView()
                .environmentObject(prefs)
        }
        // Art info popover trigger
        .sheet(isPresented: $showArtInfo) {
            ArtInfoView(artist: vm.currentArtist, sourceURL: vm.currentSourceURL)
        }
        // Keyboard shortcuts
        .onAppear { vm.reload() }
        .keyboardShortcut("r", modifiers: .command)  // handled in toolbar button
    }
    
    // MARK: - Toolbar
    
    private var toolbar: some View {
        HStack(spacing: 10) {
            // Source picker
            Picker("Source", selection: $prefs.selectedSource) {
                ForEach(ImageSource.allCases) { src in
                    Text(src.displayName).tag(src)
                }
            }
            .pickerStyle(.menu)
            .frame(width: 160)
            .onChange(of: prefs.selectedSource) { _ in
                prefs.save()
                vm.reload()
            }
            
            // Danbooru settings gear (only visible when danbooru selected)
            if prefs.selectedSource == .danbooru {
                Button {
                    showDanbooruSheet = true
                } label: {
                    Image(systemName: "gearshape")
                }
                .buttonStyle(.borderless)
                .foregroundColor(C.textDim)
                .help("Danbooru tag settings")
                .transition(.opacity)
            }
            
            Spacer()
            
            // Status
            Text(vm.statusText)
                .font(.caption)
                .foregroundColor(C.textMute)
            
            // Spinner
            if vm.isLoading {
                ProgressView()
                    .scaleEffect(0.7)
                    .progressViewStyle(.circular)
                    .tint(C.accent)
            }
            
            // Refresh button
            Button {
                vm.reload()
            } label: {
                Label("Refresh", systemImage: "arrow.clockwise")
            }
            .keyboardShortcut("r", modifiers: .command)
            .disabled(vm.isLoading)
            .buttonStyle(.borderedProminent)
            .tint(C.accent)
            .foregroundColor(.black)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(C.surface)
    }
    
    // MARK: - Image area
    
    private var imageArea: some View {
        ZStack {
            C.bg
            
            if let img = vm.image {
                Image(nsImage: img)
                    .resizable()
                    .scaledToFit()
                    .padding(8)
                    .transition(.opacity.animation(.easeIn(duration: 0.25)))
            } else if let err = vm.errorMessage {
                VStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle")
                        .font(.system(size: 40))
                        .foregroundColor(C.danger)
                    Text(err)
                        .foregroundColor(C.textDim)
                        .multilineTextAlignment(.center)
                    Button("Try again") { vm.reload() }
                        .buttonStyle(.borderedProminent)
                        .tint(C.accent)
                }
                .padding()
            } else if vm.isLoading {
                ProgressView("Loading…")
                    .progressViewStyle(.circular)
                    .tint(C.accent)
                    .foregroundColor(C.textDim)
            } else {
                Text("🐱")
                    .font(.system(size: 64))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    // MARK: - Bottom bar
    
    private var bottomBar: some View {
        HStack(spacing: 12) {
            // Auto-reload toggle
            Toggle(isOn: $prefs.autoReloadEnabled) {
                Label("Auto-reload", systemImage: "timer")
                    .foregroundColor(C.text)
                    .font(.subheadline)
            }
            .toggleStyle(.switch)
            .tint(C.accent)
            .onChange(of: prefs.autoReloadEnabled) { _ in
                prefs.save()
                vm.rescheduleAutoReload(enabled: prefs.autoReloadEnabled)
            }
            
            // NSFW picker
            Picker(selection: $prefs.nsfwMode) {
                ForEach(NSFWOption.allCases) { option in
                    Text(option.displayName)
                        .tag(option)
                }
            } label: {
                Label("NSFW", systemImage: "eye.trianglebadge.exclamationmark")
                    .foregroundColor(prefs.nsfwMode == .onlyNSFW ? C.danger : C.text)
            }
            .pickerStyle(.menu)
            .frame(width: 140)
            .onChange(of: prefs.nsfwMode) { _ in
                prefs.save()
                vm.reload()
            }
            
            Spacer()
            
            // Art info
            Button {
                showArtInfo = true
            } label: {
                Label("Art Info", systemImage: "info.circle")
            }
            .buttonStyle(.borderless)
            .foregroundColor(C.textDim)
            .disabled(vm.currentArtist == nil && vm.currentSourceURL == nil)
            
            // Save
            Button {
                vm.saveImage()
            } label: {
                Label("Save", systemImage: "arrow.down.circle.fill")
            }
            .keyboardShortcut("s", modifiers: .command)
            .buttonStyle(.borderedProminent)
            .tint(C.accent)
            .foregroundColor(.black)
            .disabled(vm.currentImageData == nil)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(C.surface2)
    }
}
