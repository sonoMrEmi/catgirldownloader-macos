// APIService.swift
// Async/await network layer for all three image sources.

import Foundation

// MARK: - Errors

enum APIError: Error, LocalizedError {
    case noURL
    case httpError(Int)
    case parseError
    case forbidden            // tag contains banned content
    case noResults

    var errorDescription: String? {
        switch self {
        case .noURL:          return "Could not build request URL"
        case .httpError(let c): return "HTTP \(c)"
        case .parseError:     return "Unexpected response format"
        case .forbidden:      return "Forbidden content filtered"
        case .noResults:      return "No results found"
        }
    }
}

// MARK: - Protocol

protocol ImageDownloaderAPI {
    func fetchImage(nsfw: NSFWOption) async throws -> FetchedImage
}

// MARK: - Shared helpers

private func download(_ url: URL) async throws -> (Data, URLResponse) {
    let config        = URLSessionConfiguration.default
    config.timeoutIntervalForRequest = 20
    let session       = URLSession(configuration: config)
    return try await session.data(from: url)
}

private func ext(from response: URLResponse) -> String? {
    guard let mime = (response as? HTTPURLResponse)?
            .value(forHTTPHeaderField: "Content-Type") else { return nil }
    if mime.contains("jpeg") || mime.contains("jpg") { return "jpg" }
    if mime.contains("png")  { return "png"  }
    if mime.contains("gif")  { return "gif"  }
    if mime.contains("webp") { return "webp" }
    return nil
}

// MARK: - 1. nekos.moe

struct CatgirlAPI: ImageDownloaderAPI {

    private let base = "https://nekos.moe/api/v1/random/image"

    func fetchImage(nsfw: NSFWOption) async throws -> FetchedImage {
        var components = URLComponents(string: base)!
        switch nsfw {
        case .blockNSFW: components.queryItems = [.init(name: "nsfw", value: "false")]
        case .onlyNSFW:  components.queryItems = [.init(name: "nsfw", value: "true")]
        case .showAll:   break
        }
        guard let metaURL = components.url else { throw APIError.noURL }

        let (metaData, metaResp) = try await download(metaURL)
        guard (metaResp as? HTTPURLResponse)?.statusCode == 200 else {
            throw APIError.httpError((metaResp as? HTTPURLResponse)?.statusCode ?? 0)
        }

        let json = try JSONSerialization.jsonObject(with: metaData) as? [String: Any]
        guard let images = json?["images"] as? [[String: Any]],
              let first  = images.first,
              let id     = first["id"] as? String else { throw APIError.parseError }

        let artist    = first["artist"] as? String
        let sourceURL = URL(string: "https://nekos.moe/post/\(id)")
        let imgURL    = URL(string: "https://nekos.moe/image/\(id)")!

        let (imgData, imgResp) = try await download(imgURL)
        let fileExt = ext(from: imgResp)
        let filename = "nekos.moe_\(id)\(fileExt.map { ".\($0)" } ?? "")"

        return FetchedImage(data: imgData, extension_: fileExt,
                            artist: artist, sourceURL: sourceURL, filename: filename)
    }
}

// MARK: - 2. waifu.im

struct WaifuAPI: ImageDownloaderAPI {

    private let base = "https://api.waifu.im/images"

    func fetchImage(nsfw: NSFWOption) async throws -> FetchedImage {
        var components = URLComponents(string: base)!
        switch nsfw {
        case .blockNSFW: components.queryItems = [.init(name: "IsNsfw", value: "False")]
        case .onlyNSFW:  components.queryItems = [.init(name: "IsNsfw", value: "True")]
        case .showAll:   components.queryItems = [.init(name: "IsNsfw", value: "All")]
        }
        guard let metaURL = components.url else { throw APIError.noURL }

        let (metaData, metaResp) = try await download(metaURL)
        guard (metaResp as? HTTPURLResponse)?.statusCode == 200 else {
            throw APIError.httpError((metaResp as? HTTPURLResponse)?.statusCode ?? 0)
        }

        let json  = try JSONSerialization.jsonObject(with: metaData) as? [String: Any]
        guard let items = json?["items"] as? [[String: Any]],
              let first = items.first,
              let urlStr = first["url"] as? String,
              let imgURL = URL(string: urlStr) else { throw APIError.parseError }

        let imageId = first["id"].map { "\($0)" } ?? "unknown"
        let source  = (first["source"] as? String).flatMap { URL(string: $0) }
        let artist: String? = {
            guard let artists = first["artists"] as? [[String: Any]],
                  let a = artists.first else { return nil }
            return a["name"] as? String
        }()

        let (imgData, imgResp) = try await download(imgURL)
        let fileExt = ext(from: imgResp)
        let filename = "waifu.im_\(imageId)\(fileExt.map { ".\($0)" } ?? "")"

        return FetchedImage(data: imgData, extension_: fileExt,
                            artist: artist, sourceURL: source, filename: filename)
    }
}

// MARK: - 3. danbooru.donmai.us

struct DanbooruAPI: ImageDownloaderAPI {

    // Tags that are blocked by Danbooru's policy (base64 encoded to avoid accidental display)
    private static let forbiddenTag1 = String(data: Data(base64Encoded: "c2hvdGE=")!, encoding: .utf8)!
    private static let forbiddenTag2 = String(data: Data(base64Encoded: "bG9saQ==")!, encoding: .utf8)!

    var tags: String   // injected from Preferences

    func fetchImage(nsfw: NSFWOption) async throws -> FetchedImage {
        for attempt in 1...5 {
            if let result = try? await _fetchOnce(nsfw: nsfw) {
                return result
            }
            if attempt == 5 { throw APIError.noResults }
        }
        throw APIError.noResults
    }

    private func _fetchOnce(nsfw: NSFWOption) async throws -> FetchedImage {
        var tagParts = tags.split(separator: " ").map(String.init)
        // Remove forbidden tags silently
        tagParts.removeAll { $0.lowercased() == Self.forbiddenTag1 || $0.lowercased() == Self.forbiddenTag2 }

        switch nsfw {
        case .blockNSFW: tagParts.append("rating:general")
        case .onlyNSFW:  tagParts.append("rating:explicit")
        case .showAll:   break
        }

        var components = URLComponents(string: "https://danbooru.donmai.us/posts.json")!
        var queryItems: [URLQueryItem] = [
            .init(name: "limit",  value: "1"),
            .init(name: "random", value: "true"),
        ]
        if !tagParts.isEmpty {
            queryItems.append(.init(name: "tags", value: tagParts.joined(separator: " ")))
        }
        components.queryItems = queryItems
        guard let metaURL = components.url else { throw APIError.noURL }

        let (metaData, metaResp) = try await download(metaURL)
        guard (metaResp as? HTTPURLResponse)?.statusCode == 200 else {
            throw APIError.httpError((metaResp as? HTTPURLResponse)?.statusCode ?? 0)
        }

        let posts = try JSONSerialization.jsonObject(with: metaData) as? [[String: Any]]
        guard let post = posts?.first else { throw APIError.noResults }

        // Check forbidden tags in result
        let postTags = (post["tag_string"] as? String ?? "").split(separator: " ").map { $0.lowercased() }
        if postTags.contains(Self.forbiddenTag1) || postTags.contains(Self.forbiddenTag2) {
            throw APIError.forbidden
        }

        guard let fileURLStr = post["file_url"] as? String,
              let imgURL = URL(string: fileURLStr) else { throw APIError.parseError }

        let postId = post["id"].map { "\($0)" } ?? "\(Int(Date().timeIntervalSince1970))"
        let artistTags = (post["tag_string_artist"] as? String ?? "")
            .split(separator: " ").first.map(String.init)
        let sourceURL = URL(string: "https://danbooru.donmai.us/posts/\(postId)")

        let (imgData, imgResp) = try await download(imgURL)
        let fileExt = ext(from: imgResp)
        let filename = "danbooru_\(postId)\(fileExt.map { ".\($0)" } ?? "")"

        return FetchedImage(data: imgData, extension_: fileExt,
                            artist: artistTags, sourceURL: sourceURL, filename: filename)
    }

    /// Returns clean tags (forbidden ones stripped)
    static func sanitize(tags: String) -> String {
        tags.split(separator: " ")
            .map(String.init)
            .filter { $0.lowercased() != forbiddenTag1 && $0.lowercased() != forbiddenTag2 }
            .joined(separator: " ")
    }
}
