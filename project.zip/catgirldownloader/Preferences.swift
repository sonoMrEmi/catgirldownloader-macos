// Preferences.swift
// Persists settings to ~/Library/Application Support/CatgirlDownloader/

import Foundation
import Combine

final class UserPreferences: ObservableObject {

    static let shared = UserPreferences()

    // Published so SwiftUI views re-render automatically
    @Published var nsfwMode:           NSFWOption  = .blockNSFW
    @Published var autoReloadEnabled:  Bool        = false
    @Published var autoReloadInterval: Int         = 5       // seconds
    @Published var danbooruTags:       String      = ""
    @Published var selectedSource:     ImageSource = .catgirl

    private let defaults: UserDefaults

    private init() {
        // Use a dedicated suite so we don't pollute the app-level defaults
        let suiteName = "moe.nyarchlinux.catgirldownloader"
        defaults = UserDefaults(suiteName: suiteName) ?? .standard
        load()
    }

    // MARK: – Persistence

    private func load() {
        if let raw = defaults.string(forKey: "nsfw_mode"),
           let opt = NSFWOption(rawValue: raw) {
            nsfwMode = opt
        }
        autoReloadEnabled  = defaults.bool(forKey: "auto_reload_enabled")
        let interval       = defaults.integer(forKey: "auto_reload_interval")
        autoReloadInterval = interval > 0 ? interval : 5
        danbooruTags       = defaults.string(forKey: "danbooru_tags") ?? ""
        if let raw = defaults.string(forKey: "source"),
           let src = ImageSource(rawValue: raw) {
            selectedSource = src
        }
    }

    func save() {
        defaults.set(nsfwMode.rawValue,      forKey: "nsfw_mode")
        defaults.set(autoReloadEnabled,      forKey: "auto_reload_enabled")
        defaults.set(autoReloadInterval,     forKey: "auto_reload_interval")
        defaults.set(danbooruTags,           forKey: "danbooru_tags")
        defaults.set(selectedSource.rawValue, forKey: "source")
    }
}
